package com.azadnet.vpn.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.azadnet.vpn.data.model.ConnectionState
import com.azadnet.vpn.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToServers: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    val servers by viewModel.servers.collectAsState()
    val selected by viewModel.selectedServer.collectAsState()
    val message by viewModel.statusMessage.collectAsState()
    val download by viewModel.downloadSpeed.collectAsState()
    val upload by viewModel.uploadSpeed.collectAsState()
    val connectedSeconds by viewModel.connectedTime.collectAsState()

    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp
    val isTablet = screenWidth >= 600
    val buttonSize = if (isTablet) 200.dp else 160.dp
    val iconSize = if (isTablet) 64.dp else 48.dp

    val buttonColor by animateColorAsState(
        targetValue = when (state) {
            ConnectionState.CONNECTED -> Color(0xFF4CAF50)
            ConnectionState.CONNECTING, ConnectionState.CHECKING, ConnectionState.RECOVERING -> Color(0xFFFFA000)
            ConnectionState.ERROR -> Color(0xFFE53935)
            else -> Color(0xFF546E7A)
        },
        label = "btnColor"
    )
    val scale by animateFloatAsState(
        targetValue = if (state == ConnectionState.CONNECTING || state == ConnectionState.CHECKING) 0.92f else 1f,
        label = "scale"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("AzadNet", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                },
                actions = {
                    IconButton(onClick = onNavigateToServers) {
                        Icon(Icons.Default.List, contentDescription = "سرورها")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "تنظیمات")
                    }
                    IconButton(onClick = onNavigateToAbout) {
                        Icon(Icons.Default.Info, contentDescription = "درباره")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = if (isTablet) 48.dp else 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(if (isTablet) 48.dp else 28.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(buttonSize + 40.dp)
                    .clip(CircleShape)
                    .background(buttonColor.copy(alpha = 0.12f))
            ) {
                Button(
                    onClick = {
                        when (state) {
                            ConnectionState.CONNECTED,
                            ConnectionState.CONNECTING,
                            ConnectionState.CHECKING,
                            ConnectionState.RECOVERING -> viewModel.disconnect()
                            else -> viewModel.connectBestServer()
                        }
                    },
                    modifier = Modifier
                        .size(buttonSize)
                        .scale(scale),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    Icon(
                        imageVector = when (state) {
                            ConnectionState.CONNECTED -> Icons.Default.PowerSettingsNew
                            ConnectionState.CONNECTING,
                            ConnectionState.CHECKING,
                            ConnectionState.RECOVERING -> Icons.Default.Sync
                            ConnectionState.ERROR -> Icons.Default.ErrorOutline
                            else -> Icons.Default.PowerSettingsNew
                        },
                        contentDescription = null,
                        modifier = Modifier.size(iconSize),
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = when (state) {
                    ConnectionState.DISCONNECTED -> "قطع"
                    ConnectionState.CHECKING -> "در حال بررسی بهترین مسیر..."
                    ConnectionState.CONNECTING -> "در حال اتصال..."
                    ConnectionState.CONNECTED -> "متصل"
                    ConnectionState.RECOVERING -> "در حال بازیابی..."
                    ConnectionState.ERROR -> "خطا"
                },
                fontSize = if (isTablet) 32.sp else 26.sp,
                fontWeight = FontWeight.Bold,
                color = buttonColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = message.ifBlank {
                    selected?.let { "${it.name}  •  ${it.latencyMs} ms" } ?: "یک کلیک برای اتصال به بهترین سرور"
                },
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            if (state == ConnectionState.CONNECTED) {
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SpeedChip("↓ دانلود", formatSpeed(download))
                    SpeedChip("↑ آپلود", formatSpeed(upload))
                    SpeedChip("زمان", formatDuration(connectedSeconds))
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            if (servers.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("بهترین مسیرها", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    TextButton(onClick = onNavigateToServers) {
                        Text("مشاهده همه")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                servers.take(3).forEach { server ->
                    CompactServerRow(
                        name = server.name,
                        protocol = server.protocol,
                        latency = server.latencyMs,
                        score = server.score,
                        isSelected = selected?.id == server.id
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("هنوز سروری بارگذاری نشده", fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "از تنظیمات منابع معتبر اضافه کنید، سپس روی دکمه اتصال بزنید تا بهترین مسیر انتخاب شود.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SpeedChip(label: String, value: String) {
    Card(shape = RoundedCornerShape(10.dp)) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun CompactServerRow(
    name: String,
    protocol: String,
    latency: Long,
    score: Float,
    isSelected: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(
                    protocol.uppercase(),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                )
            }
            Text(
                if (latency > 0) "${latency}ms" else "—",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (latency in 1..199) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private fun formatSpeed(bytesPerSec: Long): String {
    return when {
        bytesPerSec < 1024 -> "$bytesPerSec B/s"
        bytesPerSec < 1024 * 1024 -> "${bytesPerSec / 1024} KB/s"
        else -> String.format("%.1f MB/s", bytesPerSec / (1024f * 1024f))
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
