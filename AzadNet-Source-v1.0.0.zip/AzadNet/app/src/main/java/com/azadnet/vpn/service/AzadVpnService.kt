package com.azadnet.vpn.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.azadnet.vpn.MainActivity
import com.azadnet.vpn.R
import com.azadnet.vpn.core.LibboxManager
import kotlinx.coroutines.*

class AzadVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    @Volatile private var isRunning = false

    companion object {
        const val ACTION_CONNECT = "com.azadnet.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.azadnet.vpn.DISCONNECT"
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "azadnet_vpn_channel"
        private const val TAG = "AzadVpnService"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> startVpn()
            ACTION_DISCONNECT -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (isRunning) return
        serviceScope.launch {
            try {
                val builder = Builder()
                    .setSession("AzadNet")
                    .setMtu(1500)
                    .addAddress("172.19.0.1", 30)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .setBlocking(true)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.setMetered(false)
                }
                // allowBypass if needed
                // builder.allowBypass()

                tunInterface = builder.establish()
                if (tunInterface == null) {
                    Log.e(TAG, "Failed to establish TUN")
                    stopSelf()
                    return@launch
                }

                val fd = tunInterface!!.fd
                // Protect the file descriptor and start core
                val success = LibboxManager.start(this@AzadVpnService, fd)
                if (!success) {
                    Log.e(TAG, "Libbox start failed")
                    stopVpn()
                    return@launch
                }

                isRunning = true
                startForeground(NOTIFICATION_ID, createNotification(getString(R.string.status_connected)))
                Log.i(TAG, "VPN started successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Start VPN error", e)
                stopVpn()
            }
        }
    }

    private fun stopVpn() {
        isRunning = false
        try {
            LibboxManager.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Libbox stop error", e)
        }
        try {
            tunInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "TUN close error", e)
        }
        tunInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "VPN stopped")
    }

    private fun createNotification(status: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        stopVpn()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onRevoke() {
        Log.w(TAG, "VPN revoked by system")
        stopVpn()
        super.onRevoke()
    }
}
