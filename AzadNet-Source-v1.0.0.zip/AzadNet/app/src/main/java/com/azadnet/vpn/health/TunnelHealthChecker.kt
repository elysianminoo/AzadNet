package com.azadnet.vpn.health

import android.util.Log
import com.azadnet.vpn.data.model.ServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * آزمون واقعی سلامت تونل.
 * فقط بعد از موفقیت همه چک‌ها وضعیت CONNECTED اعلام می‌شود.
 */
class TunnelHealthChecker {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    private val TAG = "HealthChecker"

    data class HealthResult(
        val isHealthy: Boolean,
        val latencyMs: Long = -1,
        val error: String? = null,
        val score: Float = 0f
    )

    /**
     * آزمون کامل:
     * ۱. درخواست HTTPS به مقصد آزمایشی مجاز
     * ۲. اندازه‌گیری تأخیر
     * ۳. بررسی پاسخ معتبر
     */
    suspend fun check(server: ServerConfig? = null): HealthResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val result = withTimeoutOrNull(12_000L) {
                // مقصدهای آزمایشی عمومی و مجاز
                val testUrls = listOf(
                    "https://www.google.com/generate_204",
                    "https://cp.cloudflare.com/",
                    "https://www.gstatic.com/generate_204"
                )
                for (url in testUrls) {
                    val request = Request.Builder()
                        .url(url)
                        .header("User-Agent", "AzadNet-Health/1.0")
                        .get()
                        .build()
                    client.newCall(request).execute().use { response ->
                        if (response.code in 200..399 || response.code == 204) {
                            val latency = System.currentTimeMillis() - start
                            val score = calculateScore(latency, response.code)
                            return@withTimeoutOrNull HealthResult(
                                isHealthy = true,
                                latencyMs = latency,
                                score = score
                            )
                        }
                    }
                }
                HealthResult(false, error = "هیچ مقصد آزمایشی پاسخ نداد")
            }

            result ?: HealthResult(false, error = "Timeout در آزمون سلامت")
        } catch (e: Exception) {
            Log.w(TAG, "Health check failed: ${e.message}")
            HealthResult(false, error = e.message)
        }
    }

    private fun calculateScore(latencyMs: Long, code: Int): Float {
        var score = 100f
        when {
            latencyMs < 100 -> score += 20
            latencyMs < 200 -> score += 10
            latencyMs < 400 -> score += 0
            latencyMs < 800 -> score -= 15
            else -> score -= 30
        }
        if (code == 204 || code == 200) score += 10
        return score.coerceIn(0f, 120f)
    }

    /**
     * آزمون سریع‌تر فقط برای رتبه‌بندی اولیه (قبل از اتصال کامل)
     */
    suspend fun quickPing(address: String, port: Int): Long = withContext(Dispatchers.IO) {
        // در نسخه واقعی می‌توان از TCP connect یا ICMP استفاده کرد
        // اینجا فقط placeholder برای تأخیر تقریبی
        -1L
    }
}
