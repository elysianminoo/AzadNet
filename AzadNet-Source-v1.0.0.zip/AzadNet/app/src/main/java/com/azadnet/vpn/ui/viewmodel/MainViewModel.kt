package com.azadnet.vpn.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.azadnet.vpn.data.model.ConnectionState
import com.azadnet.vpn.data.model.ServerConfig
import com.azadnet.vpn.data.repository.ConfigRepository
import com.azadnet.vpn.service.AzadVpnService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ConfigRepository(application)

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _servers = MutableStateFlow<List<ServerConfig>>(emptyList())
    val servers: StateFlow<List<ServerConfig>> = _servers.asStateFlow()

    private val _selectedServer = MutableStateFlow<ServerConfig?>(null)
    val selectedServer: StateFlow<ServerConfig?> = _selectedServer.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _downloadSpeed = MutableStateFlow(0L)
    val downloadSpeed: StateFlow<Long> = _downloadSpeed.asStateFlow()

    private val _uploadSpeed = MutableStateFlow(0L)
    val uploadSpeed: StateFlow<Long> = _uploadSpeed.asStateFlow()

    private val _connectedTime = MutableStateFlow(0L)
    val connectedTime: StateFlow<Long> = _connectedTime.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _autoReconnect = MutableStateFlow(true)
    val autoReconnect: StateFlow<Boolean> = _autoReconnect.asStateFlow()

    private val _killSwitch = MutableStateFlow(false)
    val killSwitch: StateFlow<Boolean> = _killSwitch.asStateFlow()

    private var timerJob: Job? = null
    private val maxAttempts = 5

    init {
        viewModelScope.launch {
            _autoReconnect.value = repo.autoReconnect.first()
            _killSwitch.value = repo.killSwitch.first()
        }
    }

    /** اتصال یک‌کلیکی به بهترین سرور */
    fun connectBestServer() {
        viewModelScope.launch {
            _state.value = ConnectionState.CHECKING
            _statusMessage.value = "در حال یافتن بهترین مسیر..."

            try {
                val ranked = repo.refreshAndRank()
                _servers.value = ranked

                if (ranked.isEmpty()) {
                    _state.value = ConnectionState.ERROR
                    _statusMessage.value = "هیچ مسیر قابل‌استفاده پیدا نشد. منابع را بررسی کنید."
                    return@launch
                }

                var success = false
                var attempt = 0

                for (server in ranked.take(maxAttempts)) {
                    attempt++
                    _selectedServer.value = server
                    _state.value = ConnectionState.CONNECTING
                    _statusMessage.value = "تلاش $attempt از $maxAttempts — ${server.name}"

                    val prepareIntent = VpnService.prepare(getApplication())
                    if (prepareIntent != null) {
                        _statusMessage.value = "مجوز VPN لازم است. لطفاً تأیید کنید."
                    }

                    val intent = Intent(getApplication(), AzadVpnService::class.java).apply {
                        action = AzadVpnService.ACTION_CONNECT
                        putExtra("server_config", server.configJson)
                    }
                    getApplication<Application>().startForegroundService(intent)

                    delay(2500)

                    if (server.isHealthy || server.score > 40) {
                        success = true
                        _state.value = ConnectionState.CONNECTED
                        _statusMessage.value = "متصل به ${server.name}"
                        startTimer()
                        break
                    } else {
                        val stopIntent = Intent(getApplication(), AzadVpnService::class.java).apply {
                            action = AzadVpnService.ACTION_DISCONNECT
                        }
                        getApplication<Application>().startService(stopIntent)
                        delay(800)
                    }
                }

                if (!success) {
                    _state.value = ConnectionState.ERROR
                    _statusMessage.value = "همه مسیرها ناموفق بودند. بعداً دوباره تلاش کنید."
                    _selectedServer.value = null
                }
            } catch (e: Exception) {
                _state.value = ConnectionState.ERROR
                _statusMessage.value = "خطا: ${e.message ?: "ناشناخته"}"
            }
        }
    }

    fun selectAndConnect(server: ServerConfig) {
        viewModelScope.launch {
            _selectedServer.value = server
            _state.value = ConnectionState.CONNECTING
            _statusMessage.value = "اتصال به ${server.name}..."

            val intent = Intent(getApplication(), AzadVpnService::class.java).apply {
                action = AzadVpnService.ACTION_CONNECT
                putExtra("server_config", server.configJson)
            }
            getApplication<Application>().startForegroundService(intent)

            delay(2000)
            _state.value = ConnectionState.CONNECTED
            _statusMessage.value = "متصل به ${server.name}"
            startTimer()
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            timerJob?.cancel()
            val intent = Intent(getApplication(), AzadVpnService::class.java).apply {
                action = AzadVpnService.ACTION_DISCONNECT
            }
            getApplication<Application>().startService(intent)
            _state.value = ConnectionState.DISCONNECTED
            _statusMessage.value = "قطع شد"
            _selectedServer.value = null
            _connectedTime.value = 0
            _downloadSpeed.value = 0
            _uploadSpeed.value = 0
        }
    }

    fun refreshServers() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _statusMessage.value = "در حال به‌روزرسانی سرورها..."
            try {
                val ranked = repo.refreshAndRank()
                _servers.value = ranked
                _statusMessage.value = if (ranked.isEmpty()) "سروری یافت نشد" else "${ranked.size} سرور آماده"
            } catch (e: Exception) {
                _statusMessage.value = "خطا در به‌روزرسانی: ${e.message}"
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    fun setAutoReconnect(enabled: Boolean) {
        _autoReconnect.value = enabled
        viewModelScope.launch { repo.setAutoReconnect(enabled) }
    }

    fun setKillSwitch(enabled: Boolean) {
        _killSwitch.value = enabled
        viewModelScope.launch { repo.setKillSwitch(enabled) }
    }

    fun addSource(name: String, url: String) {
        viewModelScope.launch {
            val current = repo.getSources().toMutableList()
            current.add(com.azadnet.vpn.data.model.DiscoverySource(url = url, name = name))
            repo.saveSources(current)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var sec = 0L
            while (isActive && _state.value == ConnectionState.CONNECTED) {
                _connectedTime.value = sec
                delay(1000)
                sec++
            }
        }
    }
}
