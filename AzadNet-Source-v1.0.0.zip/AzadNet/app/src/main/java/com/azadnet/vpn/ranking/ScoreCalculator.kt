package com.azadnet.vpn.ranking

import com.azadnet.vpn.data.model.ServerConfig

/**
 * محاسبه امتیاز ترکیبی برای انتخاب بهترین مسیر.
 * فقط بر اساس ping ساده تصمیم نمی‌گیرد.
 */
object ScoreCalculator {

    fun calculate(server: ServerConfig, healthScore: Float, latencyMs: Long): Float {
        var score = 0f

        // وزن کیفیت سلامت تونل (مهم‌ترین)
        score += healthScore * 0.45f

        // وزن تأخیر
        score += when {
            latencyMs < 0 -> 0f
            latencyMs < 80 -> 30f
            latencyMs < 150 -> 25f
            latencyMs < 300 -> 18f
            latencyMs < 500 -> 10f
            latencyMs < 1000 -> 5f
            else -> 0f
        }

        // تازگی نتیجه
        val ageHours = (System.currentTimeMillis() - server.lastTestTime) / 3_600_000f
        score += when {
            ageHours < 1 -> 15f
            ageHours < 6 -> 10f
            ageHours < 24 -> 5f
            else -> 0f
        }

        // پروتکل‌های مقاوم‌تر در شرایط فیلترینگ (وزن نسبی)
        score += when (server.protocol.lowercase()) {
            "vless", "reality" -> 8f
            "hysteria2", "hy2" -> 7f
            "trojan" -> 5f
            "shadowsocks", "ss" -> 4f
            "wireguard" -> 3f
            else -> 1f
        }

        return score.coerceIn(0f, 150f)
    }

    fun rank(servers: List<ServerConfig>): List<ServerConfig> {
        return servers
            .filter { it.isHealthy || it.score > 0 }
            .sortedByDescending { it.score }
    }
}
