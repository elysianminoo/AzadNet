package com.azadnet.vpn.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "servers")
data class ServerConfig(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val protocol: String,          // vless, shadowsocks, trojan, hysteria2, wireguard ...
    val address: String,
    val port: Int,
    val configJson: String,         // کانفیگ کامل یا جزئی
    val sourceUrl: String? = null,
    val country: String? = null,
    val lastTestTime: Long = 0,
    val latencyMs: Long = -1,
    val score: Float = 0f,
    val isHealthy: Boolean = false,
    val lastError: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class DiscoverySource(
    val url: String,
    val name: String,
    val lastFetch: Long = 0,
    val successRate: Float = 0f,
    val enabled: Boolean = true
)

enum class ConnectionState {
    DISCONNECTED,
    CHECKING,
    CONNECTING,
    CONNECTED,
    RECOVERING,
    ERROR
}
