package com.azadnet.vpn.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("درباره", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "AzadNet",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text("نسخه ۱.۰.۰", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(24.dp))
            Text(
                "کلاینت VPN اندرویدی فارسی مبتنی بر موتور sing-box",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(32.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("قابلیت‌ها", fontWeight = FontWeight.SemiBold)
                    Text("• اتصال یک‌کلیکی به بهترین سرور")
                    Text("• آزمون واقعی سلامت تونل")
                    Text("• کشف و رتبه‌بندی خودکار")
                    Text("• رابط فارسی و راست‌چین")
                    Text("• پشتیبانی از اندازه‌های مختلف صفحه")
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("محدودیت‌ها", fontWeight = FontWeight.SemiBold)
                    Text("• نیاز به افزودن منابع معتبر سرور")
                    Text("• نیاز به libbox.aar برای تونل واقعی")
                    Text("• موفقیت اتصال به شرایط شبکه بستگی دارد")
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "این نرم‌افزار برای استفاده قانونی طراحی شده است.\nاز sing-box تحت مجوز GPL-3.0 پیروی می‌کند.",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}
