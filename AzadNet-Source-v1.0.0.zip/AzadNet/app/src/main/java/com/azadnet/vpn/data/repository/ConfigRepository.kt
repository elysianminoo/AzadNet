package com.azadnet.vpn.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.azadnet.vpn.data.model.DiscoverySource
import com.azadnet.vpn.data.model.ServerConfig
import com.azadnet.vpn.discovery.ServerDiscoveryEngine
import com.azadnet.vpn.health.TunnelHealthChecker
import com.azadnet.vpn.ranking.ScoreCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "azadnet_settings")

class ConfigRepository(private val context: Context) {

    private val discovery = ServerDiscoveryEngine()
    private val healthChecker = TunnelHealthChecker()

    private val SOURCES_KEY = stringPreferencesKey("discovery_sources")
    private val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
    private val KILL_SWITCH = booleanPreferencesKey("kill_switch")

    val autoReconnect: Flow<Boolean> = context.dataStore.data.map { it[AUTO_RECONNECT] ?: true }
    val killSwitch: Flow<Boolean> = context.dataStore.data.map { it[KILL_SWITCH] ?: false }

    suspend fun setAutoReconnect(enabled: Boolean) {
        context.dataStore.edit { it[AUTO_RECONNECT] = enabled }
    }

    suspend fun setKillSwitch(enabled: Boolean) {
        context.dataStore.edit { it[KILL_SWITCH] = enabled }
    }

    suspend fun getSources(): List<DiscoverySource> {
        val raw = context.dataStore.data.first()[SOURCES_KEY] ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                DiscoverySource(
                    url = o.optString("url"),
                    name = o.optString("name", "Source"),
                    enabled = o.optBoolean("enabled", true)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun saveSources(sources: List<DiscoverySource>) {
        val arr = JSONArray()
        sources.forEach {
            arr.put(JSONObject().apply {
                put("url", it.url)
                put("name", it.name)
                put("enabled", it.enabled)
            })
        }
        context.dataStore.edit { it[SOURCES_KEY] = arr.toString() }
    }

    /**
     * کشف + آزمون سلامت + رتبه‌بندی
     */
    suspend fun refreshAndRank(): List<ServerConfig> {
        val sources = getSources()
        if (sources.isEmpty()) return emptyList()

        val discovered = discovery.fetchFromSources(sources)
        val ranked = mutableListOf<ServerConfig>()

        for (server in discovered.take(30)) { // محدودیت برای جلوگیری از overload
            val health = healthChecker.check(server)
            val score = ScoreCalculator.calculate(server, health.score, health.latencyMs)
            ranked.add(
                server.copy(
                    isHealthy = health.isHealthy,
                    latencyMs = health.latencyMs,
                    score = score,
                    lastTestTime = System.currentTimeMillis(),
                    lastError = health.error
                )
            )
        }
        return ScoreCalculator.rank(ranked)
    }
}
