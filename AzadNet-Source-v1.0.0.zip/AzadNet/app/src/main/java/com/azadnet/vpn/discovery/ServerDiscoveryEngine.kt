package com.azadnet.vpn.discovery

import android.util.Log
import com.azadnet.vpn.data.model.DiscoverySource
import com.azadnet.vpn.data.model.ServerConfig
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * موتور کشف سرور از منابع عمومی و مجاز.
 * هیچ IP یا کانفیگ ساختگی تولید نمی‌کند.
 */
class ServerDiscoveryEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val gson = Gson()
    private val TAG = "DiscoveryEngine"

    // منابع پیش‌فرض قابل تنظیم (کاربر می‌تواند اضافه/حذف کند)
    private val defaultSources = listOf(
        DiscoverySource(
            url = "", // کاربر باید منابع معتبر خودش را اضافه کند
            name = "Custom Source"
        )
    )

    suspend fun fetchFromSources(sources: List<DiscoverySource>): List<ServerConfig> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<ServerConfig>()
            val seen = mutableSetOf<String>()

            for (source in sources.filter { it.enabled && it.url.isNotBlank() }) {
                try {
                    val configs = fetchSingleSource(source)
                    for (cfg in configs) {
                        val key = "${cfg.protocol}|${cfg.address}|${cfg.port}"
                        if (key !in seen) {
                            seen.add(key)
                            results.add(cfg)
                        }
                    }
                    Log.i(TAG, "Source ${source.name}: ${configs.size} configs")
                } catch (e: Exception) {
                    Log.w(TAG, "Source ${source.name} failed: ${e.message}")
                }
            }
            results
        }

    private suspend fun fetchSingleSource(source: DiscoverySource): List<ServerConfig> {
        val body = withTimeoutOrNull(20_000L) {
            val request = Request.Builder()
                .url(source.url)
                .header("User-Agent", "AzadNet/1.0")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withTimeoutOrNull null
                response.body?.string()
            }
        } ?: return emptyList()

        return parseConfigs(body, source.url)
    }

    private fun parseConfigs(raw: String, sourceUrl: String): List<ServerConfig> {
        val list = mutableListOf<ServerConfig>()
        try {
            // پشتیبانی از لیست JSON ساده یا آرایه
            val element = JsonParser.parseString(raw)
            if (element.isJsonArray) {
                element.asJsonArray.forEach { item ->
                    try {
                        val obj = item.asJsonObject
                        val name = obj.get("name")?.asString ?: obj.get("ps")?.asString ?: "Unknown"
                        val protocol = obj.get("type")?.asString
                            ?: obj.get("protocol")?.asString
                            ?: detectProtocol(obj.toString())
                        val address = obj.get("server")?.asString
                            ?: obj.get("address")?.asString
                            ?: obj.get("add")?.asString
                            ?: return@forEach
                        val port = obj.get("port")?.asInt
                            ?: obj.get("server_port")?.asInt
                            ?: 443

                        if (address.isBlank() || port <= 0) return@forEach

                        list.add(
                            ServerConfig(
                                name = name,
                                protocol = protocol,
                                address = address,
                                port = port,
                                configJson = obj.toString(),
                                sourceUrl = sourceUrl
                            )
                        )
                    } catch (_: Exception) { }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Parse error: ${e.message}")
        }
        return list
    }

    private fun detectProtocol(json: String): String {
        return when {
            json.contains("\"vless\"", true) || json.contains("reality", true) -> "vless"
            json.contains("\"shadowsocks\"", true) || json.contains("\"ss\"", true) -> "shadowsocks"
            json.contains("\"trojan\"", true) -> "trojan"
            json.contains("\"hysteria2\"", true) || json.contains("\"hy2\"", true) -> "hysteria2"
            json.contains("\"wireguard\"", true) -> "wireguard"
            else -> "unknown"
        }
    }
}
