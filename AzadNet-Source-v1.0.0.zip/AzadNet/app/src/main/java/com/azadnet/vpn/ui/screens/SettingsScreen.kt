package com.azadnet.vpn.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.azadnet.vpn.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val autoReconnect by viewModel.autoReconnect.collectAsState()
    val killSwitch by viewModel.killSwitch.collectAsState()
    val scope = rememberCoroutineScope()
    var sourceUrl by remember { mutableStateOf("") }
    var sourceName by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("اتصال", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("اتصال مجدد خودکار")
                            Text(
                                "در صورت قطع، تلاش مجدد انجام شود",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = autoReconnect,
                            onCheckedChange = { viewModel.setAutoReconnect(it) }
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("قطع امن (Kill Switch)")
                            Text(
                                "در صورت قطع VPN اینترنت مسدود شود",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = killSwitch,
                            onCheckedChange = { viewModel.setKillSwitch(it) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("منابع سرور", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

            OutlinedTextField(
                value = sourceName,
                onValueChange = { sourceName = it },
                label = { Text("نام منبع") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = sourceUrl,
                onValueChange = { sourceUrl = it },
                label = { Text("آدرس URL منبع") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("https://example.com/configs.json") }
            )
            Button(
                onClick = {
                    if (sourceUrl.isNotBlank()) {
                        scope.launch {
                            viewModel.addSource(sourceName.ifBlank { "منبع جدید" }, sourceUrl.trim())
                            sourceUrl = ""
                            sourceName = ""
                            snackbarHostState.showSnackbar("منبع اضافه شد")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("افزودن منبع")
            }

            Text(
                "توجه: فقط از منابع معتبر و مجاز استفاده کنید. برنامه هیچ IP یا کانفیگ ساختگی تولید نمی‌کند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
        }
    }
}
