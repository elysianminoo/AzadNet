package com.azadnet.vpn.core

import android.content.Context
import android.net.VpnService
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * رابط مرکزی با موتور sing-box / libbox.
 * برای نسخه واقعی باید libbox.aar را اضافه کرده و فراخوانی‌های واقعی را جایگزین کنید.
 * مستندات: https://sing-box.sagernet.org/clients/android/
 */
object LibboxManager {

    private const val TAG = "LibboxManager"
    private val running = AtomicBoolean(false)

    /**
     * شروع موتور با فایل‌دیسکریپتور TUN.
     * در نسخه واقعی:
     * - ساخت TunOptions
     * - فراخوانی Libbox.start یا BoxService
     * - protect تمام سوکت‌های outbound با service.protect(fd)
     */
    fun start(service: VpnService, tunFd: Int): Boolean {
        if (running.get()) return true
        return try {
            Log.i(TAG, "Starting core with TUN fd=$tunFd")
            // جای خالی برای فراخوانی واقعی libbox:
            // val platform = PlatformInterfaceImpl(service)
            // BoxService.start(configJson, platform, tunFd)
            running.set(true)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Core start failed", e)
            running.set(false)
            false
        }
    }

    fun stop() {
        if (!running.get()) return
        try {
            Log.i(TAG, "Stopping core")
            // BoxService.stop() یا معادل
            running.set(false)
        } catch (e: Exception) {
            Log.e(TAG, "Core stop failed", e)
        }
    }

    fun isRunning(): Boolean = running.get()

    /**
     * ساخت کانفیگ JSON برای sing-box بر اساس سرور انتخاب‌شده.
     * این تابع باید کانفیگ کامل و معتبر تولید کند.
     */
    fun buildConfig(serverJson: String): String {
        // در نسخه واقعی: تبدیل کانفیگ سرور به فرمت کامل sing-box
        // شامل inbound tun، outbound مربوطه، route، dns و ...
        return serverJson
    }
}
