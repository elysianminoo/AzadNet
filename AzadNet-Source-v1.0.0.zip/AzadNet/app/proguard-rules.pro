# AzadNet ProGuard rules
-keep class com.azadnet.vpn.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
