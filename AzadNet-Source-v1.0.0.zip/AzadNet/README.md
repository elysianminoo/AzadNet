# AzadNet v1.0.0

کلاینت VPN اندرویدی فارسی – اتصال یک‌کلیکی به بهترین سرور

## صفحات

- **خانه**: دکمه بزرگ یک‌کلیکی + وضعیت زنده + پیش‌نمایش بهترین مسیرها
- **سرورها**: فهرست کامل با امتیاز و تأخیر + انتخاب دستی
- **تنظیمات**: اتصال مجدد خودکار، Kill Switch، افزودن منابع سرور
- **درباره**: اطلاعات نسخه و محدودیت‌ها

## ویژگی‌ها

- UI فارسی راست‌چین با Jetpack Compose
- واکنش‌گرا برای گوشی و تبلت (sw600dp)
- اتصال یک‌کلیکی: کشف → رتبه‌بندی → تلاش متوالی تا ۵ مسیر
- آزمون سلامت واقعی HTTPS
- امتیاز ترکیبی (سلامت + تأخیر + تازگی + پروتکل)
- سرویس VpnService استاندارد + اعلان Foreground
- Workflow گیت‌هاب Actions آماده

## نام‌گذاری یکپارچه

- نام اپ: **AzadNet**
- Package: `com.azadnet.vpn`
- نسخه: `1.0.0` (versionCode 100)
- Artifactها: `AzadNet-Android-v1.0.0` و `AzadNet-Source-v1.0.0`

## فایل Workflow

مسیر دقیق:
`.github/workflows/unzip-and-build-v2-Batch3.yml`

## محدودیت‌های واقعی

1. باید `libbox.aar` رسمی را اضافه کنید تا تونل واقعی کار کند.
2. بدون منبع سرور معتبر، برنامه نمی‌تواند مسیری پیدا کند.
3. موفقیت build ≠ موفقیت اتصال در شبکه فیلترشده.

## ساخت

```bash
# در Android Studio
# یا با Actions روی GitHub
```

منابع رسمی:
- https://developer.android.com/develop/connectivity/vpn
- https://sing-box.sagernet.org/clients/android/
